import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from typing import Dict, Any, Tuple 


def calculate_classification_metrics(y_actual: pd.Series, y_predicted: pd.Series) -> pd.Series:
    """
    Computes key performance indicators for a binary classification model.

    Args:
        y_actual: True labels (ground truth).
        y_predicted: Predicted labels from the model.

    Returns:
        A pandas Series containing the calculated metrics.
    """
  
    acc = accuracy_score(y_actual, y_predicted)
    prec = precision_score(y_actual, y_predicted)
    rec = recall_score(y_actual, y_predicted)
    f1 = f1_score(y_actual, y_predicted)


    results_series = pd.Series({
        'Accuracy': acc,
        'Precision': prec,
        'Recall': rec,
        'F1 Score': f1
    })

    return results_series



def display_performance_summary(performance_data: pd.Series) -> None:
    """
    Presents the classification metrics in a formatted table.

    Args:
        performance_data: A pandas Series (or dictionary) of metrics.
    """
    print("✨ CLASSIFICATION PERFORMANCE SUMMARY ✨")
    

    print("| Metric | Score |")
    print("| :--- | :--- |")
    
 
    for metric_name, score in performance_data.items():
        print(f"| {metric_name.ljust(10)} | {score:.4f} |")

