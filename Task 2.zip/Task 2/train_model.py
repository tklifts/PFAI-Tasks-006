import pandas as pd
import os 
import joblib
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingClassifier 
from sklearn.metrics import accuracy_score, roc_auc_score, confusion_matrix 
from preprocess import preprocess_data 


DATA_PATH = '../data/train.csv'
MODEL_DIR = '../models/'
MODEL_NAME = 'gbt_classifier_v1.joblib' 

def load_and_prepare_data() -> tuple[pd.DataFrame, pd.Series]:
    """Loads raw data, applies preprocessing, and returns features (X) and target (y)."""
    try:
        
        df_raw = pd.read_csv(DATA_PATH)
        print(f"Data successfully loaded. Shape: {df_raw.shape}")
    except FileNotFoundError:
        print(f"Error: Training data not found at {DATA_PATH}. Exiting.")
        return None, None
    
  
    feature_matrix, target_vector = preprocess_data(df_raw)
    
    return feature_matrix, target_vector

def execute_training_pipeline():
    """Executes the core training, validation, and serialization workflow."""
    
    X_data, y_label = load_and_prepare_data()
    
    if X_data is None:
        return 
    X_trn, X_hld, y_trn, y_hld = train_test_split(
        X_data, y_label, test_size=0.15, random_state=42, stratify=y_label 
    )
    print(f"\nTraining set size: {len(X_trn)}")
    
    
    gbt_model = GradientBoostingClassifier(
        n_estimators=150, 
        learning_rate=0.05,
        max_depth=4,
        subsample=0.7,
        random_state=42
    )
    

    print("Training the Gradient Boosting Classifier...")
    gbt_model.fit(X_trn, y_trn)
    
   
    y_pred_hld = gbt_model.predict(X_hld)
    y_proba_hld = gbt_model.predict_proba(X_hld)[:, 1]


    acc = accuracy_score(y_hld, y_pred_hld)
    roc_auc = roc_auc_score(y_hld, y_proba_hld)
    conf_mat = confusion_matrix(y_hld, y_pred_hld