import pandas as pd
import numpy as np 
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler 
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer 
from sklearn.pipeline import Pipeline 


def acquire_data_from_csv(file_path: str) -> pd.DataFrame:
    """Loads a dataset from a specified CSV path."""
    print(f"Loading data from: {file_path}")
    try:
        data_frame = pd.read_csv(file_path)
        print(f"Data shape: {data_frame.shape}")
        return data_frame
    except FileNotFoundError:
        print(f"Error: File not found at {file_path}")
        return pd.DataFrame()



def build_preprocessor(df: pd.DataFrame) -> ColumnTransformer:
    """
    Constructs a ColumnTransformer to apply different preprocessing steps
    to specific columns.
    """
  
    numerical_features = df.select_dtypes(include=[np.number]).columns.tolist()
    
   
    categorical_features = ['Home.Destination', 'Cryo.Sleep', 'Species']
    
 
    for cat in categorical_features:
        if cat in numerical_features:
            numerical_features.remove(cat)
    
    
    numerical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='median')), 
        ('scaler', StandardScaler())
    ])
    
    
    categorical_transformer = Pipeline(steps=[
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('onehot', OneHotEncoder(handle_unknown='ignore', sparse_output=False, drop='first'))
    ])
    
   
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numerical_transformer, numerical_features),
            ('cat', categorical_transformer, categorical_features)
        ],
        remainder='passthrough' 
    )
    
    return preprocessor


def preprocess_and_transform(df: pd.DataFrame, preprocessor: ColumnTransformer) -> pd.DataFrame:
    """Applies the preprocessor and returns the transformed DataFrame."""
    
  
    transformed_array = preprocessor.fit_transform(df)
    
    