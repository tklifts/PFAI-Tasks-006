import pandas as pd
import joblib
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns 
from typing import Any, List, Dict 

sns.set_style("whitegrid")


def ingest_data(file_location: str) -> pd.DataFrame:
    """
    Reads a dataset from a specified CSV file path into a pandas DataFrame.

    Args:
        file_location: The full path to the CSV file.

    Returns:
        The loaded pandas DataFrame.
    """
    print(f"Reading data from: {file_location}")
    return pd.read_csv(file_location)


def serialize_model_asset(model_object: Any, destination_path: str) -> None:
    """
    Persists a trained model object to a file using joblib.

    Args:
        model_object: The trained scikit-learn model or pipeline object.
        destination_path: The file path where the model should be saved (e.g., 'model.pkl').
    """
    print(f"Serializing model to: {destination_path}")
    joblib.dump(model_object, destination_path)
    print("Serialization complete.")


def deserialize_model_asset(source_path: str) -> Any:
    """
    Loads a serialized model object from a specified file path using joblib.

    Args:
        source_path: The file path to the saved model.

    Returns:
        The loaded model object.
    """
    print(f"Loading model from: {source_path}")
    return joblib.load(source_path)


def render_feature_significance(importance_values: np.ndarray, feature_labels: List[str]) -> None:
    """
    Generates and displays a bar chart visualizing feature importances.

    Args:
        importance_values: A numpy array of feature importance scores.
        feature_labels: A list of corresponding feature names.
    """
 
    importance_df = pd.DataFrame({
        'Feature': feature_labels,
        'Importance': importance_values
    }).sort_values(by='Importance', ascending=False)
    
    print("\nDisplaying top feature significances...")

    
    plt.figure(figsize=(12, 7))
    
   
    sns.barplot(
        x='Importance', 
        y='Feature', 
        data=importance_df, 
        palette="viridis" 
    )
    
    plt.title("Model Feature Significance Assessment", fontsize=16)
    plt.xlabel("Relative Importance Score", fontsize=12)
    plt.ylabel("Features", fontsize=12)
    plt.tight_layout() 
    plt.show()