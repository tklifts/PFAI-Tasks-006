import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression # Changed the default model
from sklearn.ensemble import GradientBoostingRegressor # A stronger ensemble model alternative
from sklearn.impute import SimpleImputer # A different way to handle missing values
from sklearn.metrics import mean_squared_error, r2_score # Added R-squared

# --- Data Loading and Initial Inspection ---
# Load the primary training dataset
training_data = pd.read_csv('train.csv')

print("--- Training Data Overview ---")
print(f"Dataset Shape: {training_data.shape}")
print(f"Feature Columns:\n{training_data.columns.tolist()}")

# Identify feature types for separate preprocessing
numerical_cols = training_data.select_dtypes(include=[np.number]).columns.tolist()
# Exclude the 'target' column from numerical features if it exists
if 'target' in numerical_cols:
    numerical_cols.remove('target')

categorical_cols = training_data.select_dtypes(include=['object', 'category']).columns.tolist()

# --- Missing Value Imputation ---
print("\n--- Imputing Missing Values ---")

# 1. Numerical Imputation: Use the median for robustness against outliers
# Note: Using SimpleImputer instead of manual fillna for a different approach
numeric_imputer = SimpleImputer(strategy='median')
training_data[numerical_cols] = numeric_imputer.fit_transform(training_data[numerical_cols])

# 2. Categorical Imputation: Use the most frequent value (mode)
for col in categorical_cols:
    # Use fillna directly for mode imputation on categorical data
    mode_val = training_data[col].mode()[0]
    training_data[col] = training_data[col].fillna(mode_val)

# --- Feature Engineering: One-Hot Encoding ---
# Convert categorical variables into numerical dummy/indicator variables
processed_data = pd.get_dummies(training_data, columns=categorical_cols, drop_first=True)

# --- Feature and Target Separation ---
# Define features (X) and the dependent variable (y)
features = processed_data.drop('target', axis=1)
dependent_variable = processed_data['target']

# --- Train-Validation Split ---
# Allocate 80% for training and 20% for validation
X_train, X_val, y_train, y_val = train_test_split(
    features, dependent_variable, test_size=0.2, random_state=42
)

# --- Model Training (Linear Regression) ---
# Start with a simple, interpretable model
print("\n--- Training Linear Regression Model ---")
lr_model = LinearRegression()
lr_model.fit(X_train, y_train)

# Model Evaluation on Validation Set
validation_predictions = lr_model.predict(X_val)
validation_rmse = mean_squared_error(y_val, validation_predictions, squared=False)
validation_r2 = r2_score(y_val, validation_predictions)

print(f"Validation RMSE (Linear Reg.): {validation_rmse:.4f}")
print(f"Validation R-squared (Linear Reg.): {validation_r2:.4f}")

# --- Preparation for Test Data Prediction ---
test_set = pd.read_csv('test.csv')

# Apply the same imputation logic used on the training data
print("\n--- Preprocessing Test Data ---")
# Apply the fitted numerical imputer to the test set
test_set[numerical_cols] = numeric_imputer.transform(test_set[numerical_cols])

for col in categorical_cols:
    if col in test_set.columns:
        # Re-use the training data's mode for consistent imputation
        train_mode = training_data[col].mode()[0]
        test_set[col] = test_set[col].fillna(train_mode)

# Apply One-Hot Encoding to the test set
test_processed = pd.get_dummies(test_set, columns=categorical_cols, drop_first=True)

# Ensure the test set features match the training set features exactly
# Missing columns are added with a value of 0, and extra columns are dropped
required_features = features.columns.tolist()
test_features_aligned = test_processed.reindex(columns=required_features, fill_value=0)


# --- Generating Final Predictions (Using Linear Regression) ---
final_test_predictions = lr_model.predict(test_features_aligned)
print("\nTest Predictions (Linear Regression):\n", final_test_predictions)


# Optional: Train and predict with a more powerful model (Gradient Boosting) for variety
# gbr_model = GradientBoostingRegressor(n_estimators=100, learning_rate=0.1, max_depth=3, random_state=42)
# gbr_model.fit(X_train, y_train)
# gbr_val_preds = gbr_model.predict(X_val)
# gbr_rmse = mean_squared_error(y_val, gbr_val_preds, squared=False)
# print(f"\nValidation RMSE (GBR): {gbr_rmse:.4f}")
# gbr_test_preds = gbr_model.predict(test_features_aligned)
# print("Test Predictions (Gradient Boosting):\n", gbr_test_preds)