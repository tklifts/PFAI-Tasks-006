from flask import Flask, render_template, request
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch

app = Flask(__name__)

model_name = "distilbert-base-uncased-finetuned-sst-2-english"

tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForSequenceClassification.from_pretrained(model_name)

@app.route('/')
def home():
    return render_template('index.html')

def classify_text(text):
    inputs = tokenizer(text, return_tensors="pt", truncation=True, padding=True)

    with torch.no_grad():
        outputs = model(**inputs)

    logits = outputs.logits
    probs = torch.softmax(logits, dim=1)[0]

    label_id = torch.argmax(probs).item()

    if label_id == 1:
        label = "REAL"
    else:
        label = "FAKE"

    confidence = round(probs[label_id].item() * 100, 2)

    return label, confidence

@app.route('/predict_json', methods=['POST'])
def predict_json():
    # Accept form-encoded POST (from the frontend) or JSON
    text = None
    if request.form and 'news_text' in request.form:
        text = request.form['news_text']
    else:
        data = request.get_json(silent=True) or {}
        text = data.get('news_text')

    if not text:
        return {'error': 'No text provided'}, 400

    label, confidence = classify_text(text)
    return {'prediction': label, 'confidence': confidence}

@app.route('/predict', methods=['POST'])
def predict():
    text = request.form['news_text']
    label, confidence = classify_text(text)

    return render_template(
        'index.html',
        prediction=label,
        confidence=confidence,
        input_text=text
    )

if __name__ == '__main__':
    app.run(debug=True)