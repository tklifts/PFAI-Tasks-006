import cv2
import numpy as np
import os
from flask import Flask, render_template, request, redirect, url_for
import uuid

app = Flask(__name__)

UPLOAD_FOLDER = "static/uploads"
OUTPUT_FOLDER = "static/outputs"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        file = request.files.get("file")
        if not file:
            return "No file uploaded", 400
        
        filename = f"{uuid.uuid4().hex}_{file.filename}"
        path = os.path.join(UPLOAD_FOLDER, filename)
        file.save(path)
        
        out_name = f"processed_{filename}"
        out_path = os.path.join(OUTPUT_FOLDER, out_name)

        count = process_video(path, out_path)
        
        return render_template("index.html",
                               output_video=url_for("static", filename=f"outputs/{out_name}"),
                               count=count)
    return render_template("index.html")

def process_video(input_path, output_path):
    cap = cv2.VideoCapture(input_path)
    fgbg = cv2.createBackgroundSubtractorMOG2(history=100, varThreshold=50)

    total_objects = 0
    frame_count = 0

    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = None

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frame_count += 1
        if out is None:
            h, w = frame.shape[:2]
            out = cv2.VideoWriter(output_path, fourcc, 20.0, (w, h))

        fgmask = fgbg.apply(frame)
        # clean mask
        kernel = np.ones((5,5), np.uint8)
        fgmask = cv2.morphologyEx(fgmask, cv2.MORPH_OPEN, kernel)
        contours, _ = cv2.findContours(fgmask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        count = 0
        for c in contours:
            if cv2.contourArea(c) > 800:
                x, y, w, h = cv2.boundingRect(c)
                cv2.rectangle(frame, (x,y), (x+w, y+h), (0,255,0), 2)
                count += 1

        total_objects += count
        cv2.putText(frame, f"Objects in frame: {count}", (20,40),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,255), 2)
        out.write(frame)

    cap.release()
    out.release()
    return total_objects

if __name__ == "__main__":
    app.run(debug=True, port=5000)
