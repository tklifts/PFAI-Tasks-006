from flask import Flask, render_template, request
import pandas as pd
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np

app = Flask(__name__)

# 1. Load dataset
df = pd.read_csv("qna_dataset.csv")
questions = df['Question'].tolist()
answers = df['Answer'].tolist()

# 2. Load Hugging Face MiniLM model
model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

# 3. Encode all questions into vectors
question_embeddings = model.encode(questions, convert_to_numpy=True)

# 4. Initialize FAISS index
dimension = question_embeddings.shape[1]
index = faiss.IndexFlatL2(dimension)
index.add(question_embeddings)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get_answer', methods=['POST'])
def get_answer():
    user_question = request.form['question']

    # Embed user question
    user_embedding = model.encode([user_question], convert_to_numpy=True)

    # Search similar question
    distances, indices = index.search(user_embedding, k=1)
    answer = answers[indices[0][0]]

    return render_template('index.html', question=user_question, answer=answer)

if __name__ == '__main__':
    app.run(debug=True)
