from flask import Flask, render_template, request

app = Flask(__name__)

def get_response(user_input):
    user_input = user_input.lower()

    if "admission requirements" in user_input:
        return "You need 60% marks in Intermediate and a valid entry test score."

    elif "deadline" in user_input:
        return "The admission deadline is 15 August 2025."

    elif "programs" in user_input:
        return "We offer BSCS, BBA, BSSE, BS Psychology, and BS Mathematics."

    elif "fee" in user_input:
        return "The semester fee is around PKR 120,000."

    elif "contact" in user_input:
        return "You can contact the admission office at admissions@university.edu."

    else:
        return "Sorry, I didn’t understand that. Please ask about requirements, deadlines, or programs."

@app.route("/", methods=["GET", "POST"])
def home():
    response = ""
    if request.method == "POST":
        user_input = request.form["message"]
        response = get_response(user_input)
    return render_template("index.html", response=response)

if __name__ == "__main__":
    app.run(debug=True)
