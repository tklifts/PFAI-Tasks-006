JUG_A_CAP = 4
JUG_B_CAP = 3
TARGET = 2

START_STATE = (0, 0)

def display_step(curr, next_st, action_desc):
    print(f"STEP: {curr} -> {next_st} | Action: {action_desc}")

def generate_possible_actions(current_amounts):
    a, b = current_amounts
    
    possible_moves = []
    
    if a < JUG_A_CAP:
        possible_moves.append(((JUG_A_CAP, b), "Fill Jug A (4L)"))
    if b < JUG_B_CAP:
        possible_moves.append(((a, JUG_B_CAP), "Fill Jug B (3L)"))
        
    if a > 0:
        possible_moves.append(((0, b), "Empty Jug A"))
    if b > 0:
        possible_moves.append(((a, 0), "Empty Jug B"))
        
    if a > 0 and b < JUG_B_CAP:
        pour_amount = min(a, JUG_B_CAP - b)
        new_a = a - pour_amount
        new_b = b + pour_amount
        possible_moves.append(((new_a, new_b), "Pour A -> B"))
        
    if b > 0 and a < JUG_A_CAP:
        pour_amount = min(b, JUG_A_CAP - a)
        new_a = a + pour_amount
        new_b = b - pour_amount
        possible_moves.append(((new_a, new_b), "Pour B -> A"))
        
    return possible_moves

def search_for_solution(start_state):
    search_stack = [(start_state, [])]
    
    processed_states = set()
    
    while search_stack:
        curr_state, history = search_stack.pop()
        
        if curr_state in processed_states:
            continue
            
        processed_states.add(curr_state)
        
        if curr_state[0] == TARGET or curr_state[1] == TARGET:
            print("\n!!! SOLUTION FOUND !!!")
            
            prev_s = START_STATE
            for next_s, action in history:
                display_step(prev_s, next_s, action)
                prev_s = next_s
            
            print(f"GOAL reached at state: {curr_state}")
            return True
        
        for next_state, action_description in generate_possible_actions(curr_state):
            new_history = history + [(next_state, action_description)]
            search_stack.append((next_state, new_history))
            
    print("Search complete. No path found to the target state.")
    return False

if __name__ == "__main__":
    search_for_solution(START_STATE)