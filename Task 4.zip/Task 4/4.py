import sys

def display_grid(solution_array, size):
    for r in range(size):
        row_output = "| "
        for c in range(size):
            if solution_array[r] == c:
                row_output += "Q | "
            else:
                row_output += ". | "
        print(row_output)
    print("-" * (size * 4 + 1))


def is_valid_placement(current_arrangement, row_idx, col_idx):
    for prev_row in range(row_idx):
        prev_col = current_arrangement[prev_row]
        
        if prev_col == col_idx:
            return False
            
        if abs(prev_col - col_idx) == abs(prev_row - row_idx):
            return False
            
    return True

def recursive_solver(board_arrangement, row_to_place, dimension, found_solutions):
    if row_to_place == dimension:
        found_solutions.append(list(board_arrangement))
        return

    for target_col in range(dimension):
        
        if is_valid_placement(board_arrangement, row_to_place, target_col):
            board_arrangement[row_to_place] = target_col
            
            recursive_solver(board_arrangement, row_to_place + 1, dimension, found_solutions)
            
            board_arrangement[row_to_place] = -1 


def execute_nqueens(dim):
    initial_setup = [-1] * dim
    
    all_solutions = []
    
    recursive_solver(initial_setup, 0, dim, all_solutions)
    
    if all_solutions:
        print(f"\nFound {len(all_solutions)} total solution(s) for N={dim} Queens.")
        print("\n--- Displaying ONE Solution Example ---")
        display_grid(all_solutions[0], dim)
    else:
        print(f"\nNo solution exists for N={dim} Queens.")


if __name__ == "__main__":
    try:
        N_val = input("Please enter the board size (N): ")
        N = int(N_val)
        
        if N < 1:
            print("Error: N must be a positive integer (N >= 1).")
        elif N == 2 or N == 3:
             print(f"Note: No solutions exist for N={N}.")
             execute_nqueens(N)
        else:
            execute_nqueens(N)
            
    except ValueError:
        print("Error: Invalid input. Please enter a valid integer for N.")
